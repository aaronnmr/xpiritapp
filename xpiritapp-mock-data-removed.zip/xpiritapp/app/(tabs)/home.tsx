import { router } from "expo-router";
import { useEffect, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";

import { AmplitudeService } from "@/services/amplitude-service";
import { UnifiedDataService } from "@/services/unified-data-service";
import { XpiritDataService, type DashboardSnapshot, type WeeklyDayLoad } from "@/services/xpirit-data-service";

const weekdayLabels = ["M", "T", "W", "T", "F", "S", "S"];

export default function DashboardScreen() {
  const [dashboardSnapshot, setDashboardSnapshot] = useState<DashboardSnapshot | null>(null);
  const [gpsFeedback, setGpsFeedback] = useState<string | null>(null);
  const [isRunActionPending, setIsRunActionPending] = useState(false);
  const [runSnapshot, setRunSnapshot] = useState(UnifiedDataService.getLiveRunSnapshot());
  const [latestRun, setLatestRun] = useState<{
    distanceMeters: number;
    durationSeconds: number;
    paceSecondsPerKm: number | null;
  } | null>(null);
  const [weeklyLoad, setWeeklyLoad] = useState<WeeklyDayLoad[]>([]);

  useEffect(() => {
    void refreshDashboardSnapshot();

    const interval = setInterval(() => {
      setRunSnapshot(UnifiedDataService.getLiveRunSnapshot());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const refreshDashboardSnapshot = async () => {
    const [snapshot, weeklyLoadRecords] = await Promise.all([
      XpiritDataService.getDashboardSnapshot(),
      XpiritDataService.getWeeklyLoad()
    ]);

    if (weeklyLoadRecords) {
      setWeeklyLoad(weeklyLoadRecords);
    }

    if (!snapshot) {
      return;
    }

    setDashboardSnapshot(snapshot);

    if (snapshot.latestRun) {
      setLatestRun(snapshot.latestRun);
    }
  };

  const toggleRunTracking = async () => {
    if (isRunActionPending) {
      return;
    }

    setGpsFeedback(null);
    setIsRunActionPending(true);

    if (runSnapshot.isTracking) {
      AmplitudeService.track("live_run_end_pressed", {
        distance_meters: runSnapshot.distanceMeters,
        duration_seconds: runSnapshot.durationSeconds
      });

      try {
        const workout = await UnifiedDataService.stopLiveRun();

        if (workout) {
          AmplitudeService.track("live_run_saved", {
            distance_meters: workout.distanceMeters,
            duration_seconds: workout.durationSeconds,
            pace_seconds_per_km: workout.paceSecondsPerKm
          });
          setLatestRun({
            distanceMeters: workout.distanceMeters,
            durationSeconds: workout.durationSeconds,
            paceSecondsPerKm: workout.paceSecondsPerKm
          });
          setGpsFeedback("Run saved. Sync continues in the background.");
          void refreshDashboardSnapshot();
        }
      } catch (error) {
        setGpsFeedback(error instanceof Error ? error.message : "The run could not be stopped.");
      } finally {
        setRunSnapshot(UnifiedDataService.getLiveRunSnapshot());
        setIsRunActionPending(false);
      }
      return;
    }

    AmplitudeService.track("live_run_start_pressed");
    try {
      const snapshot = await UnifiedDataService.startLiveRun();
      setRunSnapshot(snapshot);
      setGpsFeedback("Live GPS is active. Keep Xpirit open for the most accurate live pace.");
    } catch (error) {
      setGpsFeedback(error instanceof Error ? error.message : "Location permission is required to start Live GPS.");
    } finally {
      setIsRunActionPending(false);
    }
  };

  const heroRun = runSnapshot.isTracking ? runSnapshot : latestRun;
  const hasHeroRun = runSnapshot.isTracking || latestRun !== null;

  return (
    <ScrollView className="flex-1 bg-white px-5 pt-14" contentContainerStyle={{ paddingBottom: 120 }}>
      <View className="mb-7 flex-row items-start justify-between">
        <View className="flex-1">
          <Text className="text-sm font-semibold uppercase tracking-widest text-[#808080]">Xpirit Lab</Text>
          <Text className="mt-3 text-5xl font-normal leading-[44px] tracking-[-2px] text-black">Your performance pulse.</Text>
        </View>
      </View>

      <Pressable className="overflow-hidden rounded-[24px] bg-black p-6" onPress={() => router.push("/race")}>
        <View className="absolute right-[-60px] top-[-70px] h-44 w-44 rounded-full bg-[#4a53ff] opacity-35" />
        <Text className="text-sm font-semibold uppercase tracking-widest text-[#999999]">{runSnapshot.isTracking ? "Live Run" : "Latest Run"}</Text>
        {hasHeroRun && heroRun ? (
          <>
            <View className="mt-5 flex-row items-end justify-between">
              <View>
                <Text className="text-6xl font-normal tracking-[-2px] text-white">{(heroRun.distanceMeters / 1000).toFixed(2)}</Text>
                <Text className="mt-1 text-base text-[#999999]">km covered</Text>
              </View>
              <View className="items-end">
                <Text className="text-4xl font-normal tracking-[-1px] text-white">{formatDuration(heroRun.durationSeconds)}</Text>
                <Text className="mt-1 text-base text-[#999999]">duration</Text>
              </View>
            </View>
            <Text className="mt-4 text-base font-semibold text-[#4a53ff]">{formatPace(heroRun.paceSecondsPerKm)} average pace</Text>
          </>
        ) : (
          <Text className="mt-5 text-base text-[#999999]">No runs tracked yet. Tap to start your first Live Run.</Text>
        )}
        <View className="mt-6 h-2 overflow-hidden rounded-full bg-[#191919]">
          <View className={`h-full rounded-full bg-[#4a53ff] ${runSnapshot.isTracking ? "w-[42%]" : "w-0"}`} />
        </View>
      </Pressable>

      <View className="mt-4 flex-row gap-3">
        <Pressable className="flex-1 rounded-[24px] bg-[#f3f5f9] p-5" onPress={() => router.push("/gym")}>
          <Text className="text-sm font-semibold uppercase tracking-widest text-[#808080]">Weekly Workouts</Text>
          <Text className="mt-3 text-4xl font-normal tracking-[-1px] text-black">{dashboardSnapshot?.weeklyWorkoutCount ?? "--"}</Text>
        </Pressable>
        <View className="flex-1 rounded-[24px] bg-[#f3f5f9] p-5">
          <Text className="text-sm font-semibold uppercase tracking-widest text-[#808080]">Recovery</Text>
          <Text className="mt-3 text-4xl font-normal tracking-[-1px] text-black">--</Text>
          <Text className="mt-1 text-base font-semibold text-[#4a53ff]">coming soon</Text>
        </View>
      </View>

      <View className="mt-4 rounded-[24px] bg-[#f3f5f9] p-5">
        <View className="flex-row items-center justify-between">
          <Text className="text-xl font-semibold tracking-[-0.6px] text-black">Weekly Load</Text>
          <Text className="text-base text-[#808080]">{weeklyLoad.filter((day) => day.hasActivity).length} active days</Text>
        </View>
        <View className="mt-5 h-28 flex-row items-end justify-between">
          {weeklyLoad.map((day, index) => {
            const barHeightClass = day.workoutCount === 0 ? "h-2" : day.workoutCount === 1 ? "h-16" : "h-24";

            return (
              <View key={day.isoDate} className="items-center gap-2">
                <View className={`w-7 rounded-full ${barHeightClass} ${day.hasActivity ? "bg-[#4a53ff]" : "bg-[#e5e7eb]"}`} />
                <Text className={`text-xs font-semibold ${day.hasActivity ? "text-black" : "text-[#999999]"}`}>{weekdayLabels[index]}</Text>
              </View>
            );
          })}
        </View>
      </View>

      <View className="mt-5 rounded-[24px] bg-black p-5">
        <View className="flex-row items-center justify-between">
          <View>
            <Text className="text-sm font-semibold uppercase tracking-widest text-[#999999]">Live GPS</Text>
            <Text className="mt-2 text-2xl font-semibold text-white">{runSnapshot.isTracking ? "Run in progress" : "Ready to track"}</Text>
          </View>
          <View className={`rounded-full px-4 py-2 ${runSnapshot.isTracking ? "bg-[#4a53ff]" : "bg-white"}`}>
            <Text className={`text-xs font-semibold uppercase tracking-widest ${runSnapshot.isTracking ? "text-white" : "text-black"}`}>
              {runSnapshot.isTracking ? "Live" : "Idle"}
            </Text>
          </View>
        </View>

        <View className="mt-5 flex-row gap-3">
          <View className="flex-1 rounded-[20px] bg-[#111111] p-4">
            <Text className="text-xs font-semibold uppercase tracking-widest text-[#999999]">Distance</Text>
            <Text className="mt-2 text-2xl font-semibold text-white">{formatDistance(runSnapshot.distanceMeters)}</Text>
          </View>
          <View className="flex-1 rounded-[20px] bg-[#111111] p-4">
            <Text className="text-xs font-semibold uppercase tracking-widest text-[#999999]">Pace</Text>
            <Text className="mt-2 text-2xl font-semibold text-white">{formatPace(runSnapshot.paceSecondsPerKm)}</Text>
          </View>
        </View>

        <View className="mt-3 rounded-[20px] bg-[#111111] p-4">
          <Text className="text-xs font-semibold uppercase tracking-widest text-[#999999]">Duration</Text>
          <Text className="mt-2 text-3xl font-semibold text-white">{formatDuration(runSnapshot.durationSeconds)}</Text>
        </View>

        {gpsFeedback ? <Text className="mt-4 text-sm leading-5 text-[#b5b5bd]">{gpsFeedback}</Text> : null}

        <Pressable
          className={`mt-5 rounded-full px-6 py-4 ${runSnapshot.isTracking ? "bg-white" : "bg-[#4a53ff]"} ${isRunActionPending ? "opacity-70" : ""}`}
          disabled={isRunActionPending}
          onPress={toggleRunTracking}
        >
          <Text className={`text-center text-sm font-semibold uppercase tracking-widest ${runSnapshot.isTracking ? "text-black" : "text-white"}`}>
            {isRunActionPending ? "Working..." : runSnapshot.isTracking ? "End Run" : "Start Live Run"}
          </Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

function formatDistance(meters: number) {
  return `${(meters / 1000).toFixed(2)} km`;
}

function formatPace(secondsPerKm: number | null) {
  if (!secondsPerKm) {
    return "-- /km";
  }

  const minutes = Math.floor(secondsPerKm / 60);
  const seconds = Math.round(secondsPerKm % 60)
    .toString()
    .padStart(2, "0");

  return `${minutes}:${seconds} /km`;
}

function formatDuration(seconds: number) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  }

  return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
}
